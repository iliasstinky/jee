package com.example.controller.spring.mvc.test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ControllerSpringMvcTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
